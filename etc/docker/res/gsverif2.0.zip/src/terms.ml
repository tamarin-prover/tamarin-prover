open Pitptree
open Parsing_helper

(* Unification *)

let current_bound_vars = ref []

let link v l =
  current_bound_vars := v :: (!current_bound_vars);
  v.link_v <- l

let auto_cleanup f =
  let tmp_bound_vars = !current_bound_vars in
  current_bound_vars := [];
  try
    let r = f () in
    List.iter (fun v -> v.link_v <- NoLink) (!current_bound_vars);
    current_bound_vars := tmp_bound_vars;
    r
  with x ->
    List.iter (fun v -> v.link_v <- NoLink) (!current_bound_vars);
    current_bound_vars := tmp_bound_vars;
    raise x

exception Unify

let rec occur_check v = function
  | Var v' ->
      begin
        if v == v' then raise Unify;
        match v'.link_v with
          | NoLink -> ()
          | TLink t' -> occur_check v t'
      end
  | Name _
  | Nat _ -> ()
  | Sum(v',_) -> if v == v' then raise Unify
  | Fun(_,l)
  | Tuple l -> List.iter (occur_check v) l
  | _ -> internal_error "[occur_check] Unexpected term."

let rec unify t1 t2 = match t1,t2 with
  | Var v, Var v' when v == v' -> ()
  | Var { link_v = TLink t; _}, t'
  | t', Var { link_v = TLink t; _} -> unify t t'
  | Var v, t | t, Var v ->
      occur_check v t;
      link v (TLink t)
  | Name n, Name n' when n == n' -> ()
  | Sum(x,n), Sum(x',n') when n == n' && x == x' -> ()
  | Nat n, Nat n' when n = n' -> ()
  | Fun(f1, l1), Fun(f2,l2) ->
      if f1 != f2 then raise Unify;
      List.iter2 unify l1 l2
  | Tuple l1, Tuple l2 -> List.iter2 unify l1 l2
  | _ -> raise Unify

let rec follow_term = function
  | Var { link_v = TLink t; _ } -> follow_term t
  | Fun(f,args) -> Fun(f,List.map follow_term args)
  | Tuple args -> Tuple (List.map follow_term args)
  | t -> t

let follow_term_option = function
  | None -> None
  | Some t -> Some (follow_term t)

let follow_fact = function
  | FPred(f,args) -> FPred(f,List.map follow_term args)
  | FEvent(ev,args,inj,at_op) -> FEvent(ev,List.map follow_term args,inj,follow_term_option at_op)
  | FTable(tbl,args,at_op) -> FTable(tbl,List.map follow_term args,follow_term_option at_op)
  | FMessage(t1,t2,at_op) -> FMessage(follow_term t1,follow_term t2,follow_term_option at_op)
  | FAttacker(t,at_op) -> FAttacker(follow_term t,follow_term_option at_op)

let rec follow_query = function
  | QTrue -> QTrue
  | QFalse -> QFalse
  | QFact f -> QFact (follow_fact f)
  | QOr(q1,q2) -> QOr(follow_query q1,follow_query q2)
  | QAnd(q1,q2) -> QAnd(follow_query q1,follow_query q2)
  | QNot q -> QNot (follow_query q)
  | QQuery(f,q) -> QQuery(follow_fact f,follow_query q)
